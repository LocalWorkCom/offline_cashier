<?php

namespace App\Http\Resources\Inventory;

use App\Traits\Paginatable;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PurchaseRequestItemResource extends JsonResource
{
    use Paginatable;

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray(Request $request): array
    {
        $lang = $request->header('lang', 'en');
        return [
            'id'          => $this->id,
            'pr_id'      => $this->purchase_request_id,
            'product' => $this->product ? [
                'id'   => $this->product?->id,
                'name' => $this->product?->product?->name,
            ] : null,


            'unit' => $this->unit ? [
                'id'   => $this->unit?->id,
                'name' => $this->unit?->name,
            ] : null,
            'note'=> $this->note,

            'ordered_quantity'        => (float) $this->ordered_quantity,
            'current_stock_quantity'         => (float) $this->current_stock_level,
        ];
    }
}
