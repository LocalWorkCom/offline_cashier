<?php

namespace App\Http\Resources\Inventory;

use Carbon\Carbon;
use App\Models\Brand;
use Illuminate\Http\Resources\Json\ResourceCollection;

class BrandResource extends ResourceCollection
{
    private $lang;


    public function __construct($resource, $lang = 'en')
    {
        parent::__construct($resource);
        $this->lang = $lang;
    }

    public function toArray($request)
    {
        return $this->collection->map(function ($brand) {
            return $this->formatBrandResponse($brand);
        })->toArray();
    }

    private function formatBrandResponse($brand)
    {
        $isArray = is_array($brand);

        // Prepare brand data
        $brandData = [
            'id' => $isArray ? $brand['id'] : $brand->id,
            'name' => $this->getTranslatedField($brand, 'name'),
            'name_ar' => $isArray ? $brand['name_ar'] : $brand->name_ar,
            'name_en' => $isArray ? $brand['name_en'] : $brand->name_en,
            'description' => $this->getTranslatedField($brand, 'description'),
            'description_ar' => $isArray ? ($brand['description_ar'] ?? null) : $brand->description_ar,
            'description_en' => $isArray ? ($brand['description_en'] ?? null) : $brand->description_en,
            'is_active' => (int) ($isArray ? $brand['is_active'] : $brand->is_active),
            'logo_path' => $brand->logo_path,
            'created_at' => $this->formatDateTime($isArray ? $brand['created_at'] : $brand->created_at),
            'updated_at' => $this->formatDateTime($isArray ? $brand['updated_at'] : $brand->updated_at),
            'created_by' => $this->getEmployeeName($isArray ? ($category['created_by'] ?? null) : $brand->createdBy),
            'modify_by' => $this->getEmployeeName($isArray ? ($category['modify_by'] ?? null) : $brand->modifiedBy),
        ];


        // Build response based on module status
        $response = $brandData;


        return $response;
    }

    private function getTranslatedField($item, $field)
    {
        $isArray = is_array($item);
        $fieldAr = $field . '_ar';
        $fieldEn = $field . '_en';

        if ($isArray) {
            return $this->lang == 'en' && !empty($item[$fieldEn]) ? $item[$fieldEn] : $item[$fieldAr];
        } else {
            return $this->lang == 'en' && !empty($item->$fieldEn) ? $item->$fieldEn : $item->$fieldAr;
        }
    }

    private function formatDateTime($date)
    {
        return $date ? Carbon::parse($date)->format('Y-m-d H:i:s') : null;
    }

    private function getEmployeeName($employee)
    {
        if (!$employee) {
            return null;
        }

        if (is_array($employee)) {
            return trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''));
        }

        return trim($employee->first_name . ' ' . $employee->last_name);
    }
    
}
