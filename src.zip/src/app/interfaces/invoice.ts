export interface invoice {
   "invoice_number": string,
                "invoice_print_status":string,
                "order_id": number,
                "order_type": string,
                "order_number": string,
                "order_items_count": number,
                "order_time": number
}
