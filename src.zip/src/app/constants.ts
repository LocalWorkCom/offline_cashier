export enum BasicsConstance {
  LANG = 'language',
  AR = 'العربية',
  EN = 'English',
  DefaultLang='ar' ,
  TOKEN='authToken',
  DefaultDir = 'ltr',
  employeeID = 'employee_id',
  FLAG = 'cashier',
  DIR = 'direction'
}
