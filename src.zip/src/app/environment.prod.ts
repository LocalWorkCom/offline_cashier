


//for test domain
export const baseUrl='https://offline.testdomain100.online/'
export const environment = {
  production: true,
  pusher: {
    key: 'cfd52a74b92f9e278f2d',
    cluster: 'mt1',
  }
};
//for test domain
// export const baseUrl='https://erpsystem.testdomain100.online/'
// export const environment = {
//   production: true,
//   pusher: {
//     key: 'cfd52a74b92f9e278f2d',
//     cluster: 'mt1',
//   }
// };


//alkoot


// export const baseUrl='https://alkoot-restaurant.com/'
//  export const environment = {
//    production: true,
//    pusher: {
//      key: '77f608d73899bd256cfa',
//      cluster: 'mt1',
//    }
//  };



//production


// export const baseUrl='https://productowner.testdomain100.online/'
//  export const environment = {
//  export const environment = {
//    production: true,
//    pusher: {
//      key: '77f608d73899bd256cfa',
//      cluster: 'mt1',
//    }
//  };



//production


// export const baseUrl='https://productowner.testdomain100.online/'
//  export const environment = {
//    production: true,
//    pusher: {
//      key: '77f608d73899bd256cfa',
//      cluster: 'mt1',
//    }
//  };
