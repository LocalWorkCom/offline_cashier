
export enum notificationType {
  order = 'order',
  table = 'table',
  invoice='invoice'
}
